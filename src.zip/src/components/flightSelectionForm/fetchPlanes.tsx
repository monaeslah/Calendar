import React, { useState } from 'react';


const Index= () => {

  return (
    <div className="date-picker">
     <h1>You will get planes info here</h1>
    </div>
  );
};

export default Index;
